<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-12-25 22:22:25 --> Severity: Warning --> file_get_contents(http://whatismyipaddress.com/ip/::1): failed to open stream: HTTP request failed! HTTP/1.1 403 Forbidden
 C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 19
ERROR - 2022-12-25 22:22:25 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 21
ERROR - 2022-12-25 22:22:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 21
ERROR - 2022-12-25 22:22:25 --> Severity: Notice --> Undefined offset: 9 C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 22
ERROR - 2022-12-25 22:22:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 22
ERROR - 2022-12-25 22:22:25 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 23
ERROR - 2022-12-25 22:22:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 23
ERROR - 2022-12-25 22:22:25 --> Severity: Notice --> Undefined offset: 12 C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 24
ERROR - 2022-12-25 22:22:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 24
ERROR - 2022-12-25 22:22:25 --> Severity: Notice --> Undefined offset: 7 C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 25
ERROR - 2022-12-25 22:22:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 25
ERROR - 2022-12-25 22:22:26 --> Severity: Warning --> file_get_contents(http://whatismyipaddress.com/ip/::1): failed to open stream: HTTP request failed! HTTP/1.1 403 Forbidden
 C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 19
ERROR - 2022-12-25 22:22:26 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 21
ERROR - 2022-12-25 22:22:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 21
ERROR - 2022-12-25 22:22:26 --> Severity: Notice --> Undefined offset: 9 C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 22
ERROR - 2022-12-25 22:22:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 22
ERROR - 2022-12-25 22:22:26 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 23
ERROR - 2022-12-25 22:22:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 23
ERROR - 2022-12-25 22:22:26 --> Severity: Notice --> Undefined offset: 12 C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 24
ERROR - 2022-12-25 22:22:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 24
ERROR - 2022-12-25 22:22:26 --> Severity: Notice --> Undefined offset: 7 C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 25
ERROR - 2022-12-25 22:22:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 25
ERROR - 2022-12-25 22:23:33 --> Severity: Warning --> file_get_contents(https://whatismyipaddress.com/ip/::1): failed to open stream: HTTP request failed! HTTP/1.1 403 Forbidden
 C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 19
ERROR - 2022-12-25 22:23:33 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 21
ERROR - 2022-12-25 22:23:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 21
ERROR - 2022-12-25 22:23:33 --> Severity: Notice --> Undefined offset: 9 C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 22
ERROR - 2022-12-25 22:23:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 22
ERROR - 2022-12-25 22:23:33 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 23
ERROR - 2022-12-25 22:23:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 23
ERROR - 2022-12-25 22:23:33 --> Severity: Notice --> Undefined offset: 12 C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 24
ERROR - 2022-12-25 22:23:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 24
ERROR - 2022-12-25 22:23:33 --> Severity: Notice --> Undefined offset: 7 C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 25
ERROR - 2022-12-25 22:23:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 25
ERROR - 2022-12-25 22:25:55 --> Severity: Notice --> Undefined variable: ip C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 18
ERROR - 2022-12-25 22:26:32 --> Severity: Notice --> Undefined variable: ip C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 21
ERROR - 2022-12-25 22:28:09 --> Severity: error --> Exception: Call to undefined function getIpInfo() C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 19
ERROR - 2022-12-25 22:30:12 --> Severity: Warning --> file_get_contents(http://whatismyipaddress.com/ip/::1): failed to open stream: HTTP request failed! HTTP/1.1 403 Forbidden
 C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 26
ERROR - 2022-12-25 22:30:12 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 30
ERROR - 2022-12-25 22:30:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 30
ERROR - 2022-12-25 22:30:12 --> Severity: Notice --> Undefined offset: 11 C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 31
ERROR - 2022-12-25 22:30:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 31
ERROR - 2022-12-25 22:30:12 --> Severity: Notice --> Undefined offset: 10 C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 32
ERROR - 2022-12-25 22:30:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 32
ERROR - 2022-12-25 22:30:12 --> Severity: Notice --> Undefined offset: 15 C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 33
ERROR - 2022-12-25 22:30:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 33
ERROR - 2022-12-25 22:30:12 --> Severity: Notice --> Undefined offset: 9 C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 34
ERROR - 2022-12-25 22:30:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 34
ERROR - 2022-12-25 22:35:27 --> Severity: error --> Exception: Call to undefined function getIP() C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 18
