<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-12-22 03:36:50 --> 404 Page Not Found: Nuruljpg/index
ERROR - 2022-12-22 03:37:24 --> 404 Page Not Found: Nuruljpg/index
ERROR - 2022-12-22 03:53:43 --> 404 Page Not Found: GetuserAll/index
ERROR - 2022-12-22 03:54:30 --> 404 Page Not Found: GetuserAll/index
ERROR - 2022-12-22 10:44:14 --> Severity: Notice --> Undefined variable: filename C:\xampp\htdocs\sekolah_fe\application\helpers\config_upload_helper.php 6
ERROR - 2022-12-22 05:30:28 --> 404 Page Not Found: Users/upload
ERROR - 2022-12-22 05:30:28 --> 404 Page Not Found: Users/upload
ERROR - 2022-12-22 11:30:43 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 14
ERROR - 2022-12-22 11:31:31 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 14
ERROR - 2022-12-22 11:34:16 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 14
ERROR - 2022-12-22 11:34:21 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 14
ERROR - 2022-12-22 07:22:48 --> 404 Page Not Found: JenisNilai/get
ERROR - 2022-12-22 07:22:57 --> 404 Page Not Found: JenisNilai/get
ERROR - 2022-12-22 07:23:54 --> 404 Page Not Found: JenisNilai/get
ERROR - 2022-12-22 07:24:02 --> 404 Page Not Found: JenisNilai/get
ERROR - 2022-12-22 07:24:43 --> 404 Page Not Found: JenisNilai/get
ERROR - 2022-12-22 07:38:56 --> 404 Page Not Found: Jenisnilai/delete
ERROR - 2022-12-22 07:38:59 --> 404 Page Not Found: Jenisnilai/delete
ERROR - 2022-12-22 14:13:16 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 14
ERROR - 2022-12-22 08:17:50 --> 404 Page Not Found: Nuruljpg/index
ERROR - 2022-12-22 08:17:58 --> 404 Page Not Found: Nuruljpg/index
ERROR - 2022-12-22 14:31:55 --> Severity: Notice --> Undefined index: no_telp C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 238
ERROR - 2022-12-22 14:31:55 --> Severity: Notice --> Undefined index: no_telp C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 238
ERROR - 2022-12-22 14:31:55 --> Severity: Notice --> Undefined index: no_telp C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 238
ERROR - 2022-12-22 14:31:55 --> Severity: Notice --> Undefined index: no_telp C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 238
ERROR - 2022-12-22 14:32:52 --> Severity: Notice --> Undefined index: no_telp C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 238
ERROR - 2022-12-22 14:32:52 --> Severity: Notice --> Undefined index: no_telp C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 238
ERROR - 2022-12-22 14:32:52 --> Severity: Notice --> Undefined index: no_telp C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 238
ERROR - 2022-12-22 14:32:52 --> Severity: Notice --> Undefined index: no_telp C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 238
ERROR - 2022-12-22 08:33:09 --> 404 Page Not Found: Nuruljpg/index
ERROR - 2022-12-22 08:33:59 --> 404 Page Not Found: Nuruljpg/index
ERROR - 2022-12-22 08:34:25 --> 404 Page Not Found: Nuruljpg/index
ERROR - 2022-12-22 08:34:37 --> 404 Page Not Found: Nuruljpg/index
ERROR - 2022-12-22 08:41:17 --> 404 Page Not Found: Upload/murid
ERROR - 2022-12-22 08:43:08 --> 404 Page Not Found: Upload/murid
ERROR - 2022-12-22 08:45:35 --> 404 Page Not Found: Upload/murid
ERROR - 2022-12-22 08:47:45 --> 404 Page Not Found: Upload/murid
ERROR - 2022-12-22 08:48:07 --> 404 Page Not Found: Upload/murid
ERROR - 2022-12-22 08:54:00 --> 404 Page Not Found: Upload/murid
ERROR - 2022-12-22 08:54:59 --> 404 Page Not Found: Upload/murid
ERROR - 2022-12-22 09:00:52 --> 404 Page Not Found: Upload/murid
ERROR - 2022-12-22 09:14:07 --> 404 Page Not Found: Upload/murid
ERROR - 2022-12-22 09:14:54 --> 404 Page Not Found: Murid/murid
ERROR - 2022-12-22 09:14:54 --> 404 Page Not Found: Upload/murid
ERROR - 2022-12-22 09:16:51 --> 404 Page Not Found: Murid/murid
ERROR - 2022-12-22 09:16:51 --> 404 Page Not Found: Upload/murid
ERROR - 2022-12-22 09:21:01 --> 404 Page Not Found: Murid/murid
ERROR - 2022-12-22 09:21:01 --> 404 Page Not Found: Upload/murid
ERROR - 2022-12-22 09:22:49 --> 404 Page Not Found: Murid/murid
ERROR - 2022-12-22 09:22:49 --> 404 Page Not Found: Upload/murid
ERROR - 2022-12-22 10:05:52 --> 404 Page Not Found: Upload/murid
ERROR - 2022-12-22 10:05:52 --> 404 Page Not Found: Murid/murid
ERROR - 2022-12-22 10:06:06 --> 404 Page Not Found: Murid/murid
ERROR - 2022-12-22 10:16:35 --> 404 Page Not Found: GetOptionAll/index
ERROR - 2022-12-22 16:38:54 --> 404 Page Not Found: Role/page
ERROR - 2022-12-22 16:46:55 --> 404 Page Not Found: Role/page
ERROR - 2022-12-22 22:48:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 299
ERROR - 2022-12-22 22:48:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 300
ERROR - 2022-12-22 22:48:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 306
ERROR - 2022-12-22 22:48:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 306
ERROR - 2022-12-22 22:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 299
ERROR - 2022-12-22 22:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 300
ERROR - 2022-12-22 22:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 306
ERROR - 2022-12-22 22:48:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 306
ERROR - 2022-12-22 22:58:30 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\sekolah_fe\application\controllers\Master.php 295
ERROR - 2022-12-22 17:00:31 --> 404 Page Not Found: Users/users
