<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-12-23 00:02:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Auth.php 23
ERROR - 2022-12-23 11:15:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-23 11:15:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-23 05:16:52 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 05:16:56 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 11:17:30 --> Query error: Table 'sekolah_fe.menu_config' doesn't exist - Invalid query: SELECT *
FROM `menu_config`
ERROR - 2022-12-23 05:17:30 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:03:51 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:03:51 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:04:48 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:04:48 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:04:59 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:04:59 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 07:10:33 --> 404 Page Not Found: Localhost/sekolah_fe
ERROR - 2022-12-23 13:10:33 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:10:33 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 07:11:59 --> 404 Page Not Found: Localhost/sekolah_fe
ERROR - 2022-12-23 13:11:59 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:11:59 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 07:12:09 --> 404 Page Not Found: Localhost/sekolah_fe
ERROR - 2022-12-23 13:12:39 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:12:39 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:14:53 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:14:53 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:14:57 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:14:57 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:15:57 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:15:57 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:16:04 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:16:04 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:16:50 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 13:16:50 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 13:16:51 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:16:51 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:16:56 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:16:56 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:17:06 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:17:06 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:18:04 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:18:04 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:18:53 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:18:53 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:19:52 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:19:52 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:20:24 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:20:24 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:20:42 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:20:42 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:21:06 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:21:06 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:21:29 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:21:29 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:21:43 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:21:43 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:22:39 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:22:39 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:22:40 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:22:40 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:23:07 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:23:07 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:24:19 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:24:19 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:24:41 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 13:24:42 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:24:42 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:24:44 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:24:44 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:25:58 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:25:58 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:26:01 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:26:01 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:27:02 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 13:27:02 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:27:02 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:32:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Master.php 10
ERROR - 2022-12-23 13:33:28 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:33:28 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:33:50 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:33:50 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:34:36 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:34:36 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:47:51 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:47:51 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:49:01 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:49:01 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:50:14 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:50:14 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:50:49 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:50:49 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:51:16 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:51:16 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 13:54:52 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 07:54:52 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 14:26:46 --> Severity: Notice --> Undefined index: kategori C:\xampp\htdocs\sekolah_fe\application\views\main.php 94
ERROR - 2022-12-23 14:26:46 --> Severity: Notice --> Undefined index: kategori C:\xampp\htdocs\sekolah_fe\application\views\main.php 94
ERROR - 2022-12-23 14:26:46 --> Severity: Notice --> Undefined index: kategori C:\xampp\htdocs\sekolah_fe\application\views\main.php 94
ERROR - 2022-12-23 14:26:46 --> Severity: Notice --> Undefined index: kategori C:\xampp\htdocs\sekolah_fe\application\views\main.php 94
ERROR - 2022-12-23 14:26:46 --> Severity: Notice --> Undefined index: kategori C:\xampp\htdocs\sekolah_fe\application\views\main.php 94
ERROR - 2022-12-23 14:26:46 --> Severity: Notice --> Undefined index: kategori C:\xampp\htdocs\sekolah_fe\application\views\main.php 94
ERROR - 2022-12-23 14:26:46 --> Severity: Notice --> Undefined index: kategori C:\xampp\htdocs\sekolah_fe\application\views\main.php 94
ERROR - 2022-12-23 14:26:46 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 08:26:46 --> 404 Page Not Found: Upload/Image_not_available.png
ERROR - 2022-12-23 08:27:15 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-23 14:27:17 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 17
ERROR - 2022-12-23 08:33:19 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-23 08:33:30 --> 404 Page Not Found: Absen/page
ERROR - 2022-12-23 08:34:35 --> 404 Page Not Found: Absen/page
ERROR - 2022-12-23 08:41:18 --> 404 Page Not Found: Assets/vendor
