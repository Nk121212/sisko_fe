<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-12-20 09:33:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 39
ERROR - 2022-12-20 09:33:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 40
ERROR - 2022-12-20 09:33:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 46
ERROR - 2022-12-20 09:33:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 46
ERROR - 2022-12-20 03:33:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-12-20 09:33:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 39
ERROR - 2022-12-20 09:33:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 40
ERROR - 2022-12-20 09:33:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 46
ERROR - 2022-12-20 09:33:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 46
ERROR - 2022-12-20 11:14:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 39
ERROR - 2022-12-20 11:14:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 40
ERROR - 2022-12-20 11:14:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 46
ERROR - 2022-12-20 11:14:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 46
ERROR - 2022-12-20 05:27:22 --> 404 Page Not Found: Vendor/fontawesome-free
ERROR - 2022-12-20 05:27:22 --> 404 Page Not Found: Css/sb-admin-2.min.css
ERROR - 2022-12-20 05:27:22 --> 404 Page Not Found: Img/undraw_rocket.svg
ERROR - 2022-12-20 05:27:22 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2022-12-20 05:27:22 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2022-12-20 05:27:22 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2022-12-20 05:27:22 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2022-12-20 05:27:22 --> 404 Page Not Found: Vendor/jquery
ERROR - 2022-12-20 05:27:22 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2022-12-20 05:27:22 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-20 05:27:22 --> 404 Page Not Found: Vendor/jquery-easing
ERROR - 2022-12-20 05:27:22 --> 404 Page Not Found: Js/sb-admin-2.min.js
ERROR - 2022-12-20 05:27:22 --> 404 Page Not Found: Vendor/chart.js
ERROR - 2022-12-20 05:27:22 --> 404 Page Not Found: Js/demo
ERROR - 2022-12-20 05:27:22 --> 404 Page Not Found: Js/demo
ERROR - 2022-12-20 05:28:47 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2022-12-20 05:28:47 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2022-12-20 05:28:47 --> 404 Page Not Found: Img/undraw_rocket.svg
ERROR - 2022-12-20 05:28:47 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2022-12-20 05:28:47 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2022-12-20 05:28:47 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2022-12-20 11:42:22 --> Severity: error --> Exception: Object of class CI_Loader could not be converted to string C:\xampp\htdocs\sekolah_fe\application\views\main.php 367
ERROR - 2022-12-20 11:42:36 --> Severity: error --> Exception: Object of class CI_Loader could not be converted to string C:\xampp\htdocs\sekolah_fe\application\views\main.php 367
ERROR - 2022-12-20 11:43:05 --> Severity: error --> Exception: Object of class CI_Loader could not be converted to string C:\xampp\htdocs\sekolah_fe\application\views\main.php 367
ERROR - 2022-12-20 11:46:08 --> Severity: error --> Exception: Object of class CI_Loader could not be converted to string C:\xampp\htdocs\sekolah_fe\application\views\main.php 367
ERROR - 2022-12-20 11:46:35 --> Severity: error --> Exception: Object of class CI_Loader could not be converted to string C:\xampp\htdocs\sekolah_fe\application\views\main.php 367
ERROR - 2022-12-20 11:46:38 --> Severity: error --> Exception: Object of class CI_Loader could not be converted to string C:\xampp\htdocs\sekolah_fe\application\views\main.php 367
ERROR - 2022-12-20 11:47:40 --> Severity: error --> Exception: Object of class CI_Loader could not be converted to string C:\xampp\htdocs\sekolah_fe\application\views\main.php 384
ERROR - 2022-12-20 11:48:14 --> Severity: error --> Exception: Object of class CI_Loader could not be converted to string C:\xampp\htdocs\sekolah_fe\application\views\main.php 371
ERROR - 2022-12-20 11:48:18 --> Severity: error --> Exception: Object of class CI_Loader could not be converted to string C:\xampp\htdocs\sekolah_fe\application\views\main.php 371
ERROR - 2022-12-20 11:49:20 --> Severity: error --> Exception: Object of class CI_Loader could not be converted to string C:\xampp\htdocs\sekolah_fe\application\views\main.php 371
ERROR - 2022-12-20 12:03:16 --> Severity: Notice --> Undefined variable: my_key C:\xampp\htdocs\sekolah_fe\application\helpers\dbconfig_helper.php 30
ERROR - 2022-12-20 12:03:16 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\sekolah_fe\application\helpers\dbconfig_helper.php 30
ERROR - 2022-12-20 12:03:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\helpers\dbconfig_helper.php 30
ERROR - 2022-12-20 12:05:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\sekolah_fe\application\helpers\dbconfig_helper.php 30
ERROR - 2022-12-20 12:07:47 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\sekolah_fe\application\helpers\dbconfig_helper.php 25
ERROR - 2022-12-20 12:07:47 --> Severity: Warning --> Illegal offset type C:\xampp\htdocs\sekolah_fe\application\helpers\dbconfig_helper.php 26
ERROR - 2022-12-20 12:07:47 --> Severity: Warning --> Illegal offset type C:\xampp\htdocs\sekolah_fe\application\helpers\dbconfig_helper.php 27
ERROR - 2022-12-20 12:17:00 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 85
ERROR - 2022-12-20 12:17:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 85
ERROR - 2022-12-20 12:18:54 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 85
ERROR - 2022-12-20 12:18:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 85
ERROR - 2022-12-20 12:19:40 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 85
ERROR - 2022-12-20 12:19:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 85
ERROR - 2022-12-20 12:19:43 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 85
ERROR - 2022-12-20 12:19:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 85
ERROR - 2022-12-20 12:28:50 --> Severity: Warning --> Use of undefined constant value - assumed 'value' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\sekolah_fe\application\views\logged_in\dashboard.php 40
ERROR - 2022-12-20 12:28:50 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\sekolah_fe\application\views\logged_in\dashboard.php 40
ERROR - 2022-12-20 12:28:50 --> Severity: Warning --> Use of undefined constant value - assumed 'value' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\sekolah_fe\application\views\logged_in\dashboard.php 40
ERROR - 2022-12-20 12:28:50 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\sekolah_fe\application\views\logged_in\dashboard.php 40
ERROR - 2022-12-20 12:28:50 --> Severity: Warning --> Use of undefined constant value - assumed 'value' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\sekolah_fe\application\views\logged_in\dashboard.php 40
ERROR - 2022-12-20 12:28:50 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\sekolah_fe\application\views\logged_in\dashboard.php 40
ERROR - 2022-12-20 13:01:26 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:01:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:03:29 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:03:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 07:03:29 --> 404 Page Not Found: GetGuruAll/index
ERROR - 2022-12-20 07:03:38 --> 404 Page Not Found: GetGuruAll/index
ERROR - 2022-12-20 07:04:47 --> 404 Page Not Found: Table_json/get_guru_all
ERROR - 2022-12-20 13:04:50 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:04:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 07:04:50 --> 404 Page Not Found: Table_json/get_guru_all
ERROR - 2022-12-20 07:04:58 --> 404 Page Not Found: Table_json/get_guru_all
ERROR - 2022-12-20 13:05:42 --> Severity: error --> Exception: Call to undefined method M_curl::getGuruAll() C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 65
ERROR - 2022-12-20 13:05:46 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:05:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:05:46 --> Severity: error --> Exception: Call to undefined method M_curl::getGuruAll() C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 65
ERROR - 2022-12-20 13:05:49 --> Severity: error --> Exception: Call to undefined method M_curl::getGuruAll() C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 65
ERROR - 2022-12-20 13:06:30 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:06:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:07:59 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:07:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:13:16 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:13:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:14:57 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:14:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:15:00 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:15:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 07:15:15 --> 404 Page Not Found: Master/add_guru
ERROR - 2022-12-20 07:15:23 --> 404 Page Not Found: Master/add_guru
ERROR - 2022-12-20 13:19:35 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:19:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:23:28 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:23:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:23:58 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:23:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:26:35 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:26:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:27:04 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:27:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:27:23 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:27:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:30:15 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:30:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:30:18 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:30:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:30:39 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:30:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:41:56 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:41:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:42:51 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:42:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:44:13 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:44:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:44:28 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:44:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:44:29 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:44:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:44:29 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:44:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:44:29 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:44:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:44:29 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:44:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:44:29 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:44:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:44:29 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:44:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:44:30 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:44:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:44:32 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:44:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:46:42 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:46:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:50:34 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:50:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:52:52 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:52:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:56:22 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:56:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:56:44 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:56:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:58:12 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:58:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:58:12 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:58:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:58:12 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:58:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:58:15 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:58:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:58:24 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:58:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:58:27 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:58:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:58:43 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:58:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:58:43 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:58:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:58:43 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:58:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:58:43 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:58:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:58:44 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:58:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:58:44 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:58:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:58:44 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:58:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:58:46 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 13:58:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 08:02:08 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:02:08 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:02:37 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:02:37 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:02:41 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:02:41 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:02:58 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:02:58 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-12-20 08:02:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-12-20 08:02:58 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:02:58 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:02:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-12-20 08:02:58 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:02:58 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:02:58 --> 404 Page Not Found: Assets/images
ERROR - 2022-12-20 08:02:58 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:02:58 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:02:58 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:02:58 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:02:58 --> 404 Page Not Found: Assets/images
ERROR - 2022-12-20 08:02:59 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:02:59 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:02:59 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-12-20 08:02:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-12-20 08:02:59 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:02:59 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:02:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-12-20 08:02:59 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:02:59 --> 404 Page Not Found: Assets/images
ERROR - 2022-12-20 08:02:59 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:02:59 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:02:59 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:02:59 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:02:59 --> 404 Page Not Found: Assets/images
ERROR - 2022-12-20 08:03:07 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:03:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-12-20 08:03:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-12-20 08:03:07 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:03:07 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:03:07 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:03:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-12-20 08:03:07 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:03:07 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:03:07 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:03:07 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:03:07 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:03:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-12-20 08:03:07 --> 404 Page Not Found: Assets/images
ERROR - 2022-12-20 08:03:07 --> 404 Page Not Found: Assets/images
ERROR - 2022-12-20 08:04:39 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 08:04:42 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-20 21:25:46 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 21:25:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 21:27:06 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 21:27:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 21:27:42 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 21:27:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 21:27:45 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 21:27:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 21:28:45 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 21:28:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 15:31:28 --> Severity: error --> Exception: Too few arguments to function Master::__construct(), 0 passed in C:\xampp\htdocs\sekolah_fe\system\core\CodeIgniter.php on line 519 and exactly 1 expected C:\xampp\htdocs\sekolah_fe\application\controllers\Master.php 6
ERROR - 2022-12-20 15:31:48 --> Severity: error --> Exception: Call to undefined function getMenu() C:\xampp\htdocs\sekolah_fe\application\controllers\Master.php 7
ERROR - 2022-12-20 21:43:10 --> Severity: Notice --> Undefined variable: my_menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 21:43:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 21:45:30 --> Severity: Notice --> Undefined variable: my_menu C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 21:45:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\main.php 93
ERROR - 2022-12-20 21:46:21 --> Severity: Notice --> Undefined variable: my_menu C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 8
ERROR - 2022-12-20 21:46:56 --> Severity: Notice --> Undefined variable: my_menu C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 8
ERROR - 2022-12-20 21:46:57 --> Severity: Notice --> Undefined variable: my_menu C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 8
ERROR - 2022-12-20 21:46:57 --> Severity: Notice --> Undefined variable: my_menu C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 8
ERROR - 2022-12-20 21:49:41 --> Severity: Notice --> Undefined variable: my_menu C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 8
ERROR - 2022-12-20 21:49:42 --> Severity: Notice --> Undefined variable: my_menu C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 8
ERROR - 2022-12-20 21:49:43 --> Severity: Notice --> Undefined variable: my_menu C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 8
ERROR - 2022-12-20 21:57:09 --> Severity: Notice --> Undefined variable: class C:\xampp\htdocs\sekolah_fe\application\views\main.php 88
ERROR - 2022-12-20 21:58:22 --> Severity: Notice --> Undefined variable: class C:\xampp\htdocs\sekolah_fe\application\views\main.php 88
ERROR - 2022-12-20 22:01:00 --> Severity: Notice --> Undefined variable: CI C:\xampp\htdocs\sekolah_fe\application\helpers\my_helper.php 6
ERROR - 2022-12-20 22:01:00 --> Severity: Notice --> Trying to get property 'router' of non-object C:\xampp\htdocs\sekolah_fe\application\helpers\my_helper.php 6
ERROR - 2022-12-20 22:01:00 --> Severity: error --> Exception: Call to a member function fetch_class() on null C:\xampp\htdocs\sekolah_fe\application\helpers\my_helper.php 6
ERROR - 2022-12-20 22:14:03 --> Severity: Notice --> Undefined variable: class C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 18
ERROR - 2022-12-20 22:14:03 --> Severity: Notice --> Undefined variable: class C:\xampp\htdocs\sekolah_fe\application\core\SEKOLAH_Controller.php 18
ERROR - 2022-12-20 22:30:40 --> Severity: error --> Exception: Call to undefined method M_curl::getPelajaranAll() C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 102
