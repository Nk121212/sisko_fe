<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-12-21 18:04:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 11
ERROR - 2022-12-21 18:04:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 11
ERROR - 2022-12-21 18:04:47 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 12
ERROR - 2022-12-21 18:04:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 23
ERROR - 2022-12-21 18:04:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\logged_in\dashboard.php 86
ERROR - 2022-12-21 18:51:15 --> Severity: Notice --> Undefined index: nik C:\xampp\htdocs\sekolah_fe\application\views\logged_in\dashboard.php 94
ERROR - 2022-12-21 18:51:15 --> Severity: Notice --> Undefined index: nik C:\xampp\htdocs\sekolah_fe\application\views\logged_in\dashboard.php 94
ERROR - 2022-12-21 18:51:15 --> Severity: Notice --> Undefined index: nik C:\xampp\htdocs\sekolah_fe\application\views\logged_in\dashboard.php 94
ERROR - 2022-12-21 18:52:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 39
ERROR - 2022-12-21 18:52:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 40
ERROR - 2022-12-21 18:52:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 46
ERROR - 2022-12-21 18:52:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 46
ERROR - 2022-12-21 18:52:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 39
ERROR - 2022-12-21 18:52:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 40
ERROR - 2022-12-21 18:52:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 46
ERROR - 2022-12-21 18:52:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 46
ERROR - 2022-12-21 18:52:26 --> Severity: Notice --> Undefined index: search C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 31
ERROR - 2022-12-21 18:52:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 31
ERROR - 2022-12-21 18:52:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 39
ERROR - 2022-12-21 18:52:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 40
ERROR - 2022-12-21 18:52:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 46
ERROR - 2022-12-21 18:52:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 46
ERROR - 2022-12-21 19:37:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 13
ERROR - 2022-12-21 19:37:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 13
ERROR - 2022-12-21 19:37:35 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 14
ERROR - 2022-12-21 19:37:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 25
ERROR - 2022-12-21 19:37:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\logged_in\dashboard.php 86
ERROR - 2022-12-21 19:38:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 13
ERROR - 2022-12-21 19:38:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 13
ERROR - 2022-12-21 19:38:03 --> Severity: Warning --> Division by zero C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 14
ERROR - 2022-12-21 19:38:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 25
ERROR - 2022-12-21 19:38:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\logged_in\dashboard.php 86
ERROR - 2022-12-21 19:56:03 --> Severity: Warning --> Illegal string offset 'data' C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 13
ERROR - 2022-12-21 19:56:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 13
ERROR - 2022-12-21 19:56:03 --> Severity: Warning --> Illegal string offset 'data' C:\xampp\htdocs\sekolah_fe\application\controllers\Home.php 25
ERROR - 2022-12-21 19:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\logged_in\dashboard.php 86
ERROR - 2022-12-21 13:56:23 --> 404 Page Not Found: Nuruljpg/index
ERROR - 2022-12-21 14:00:10 --> 404 Page Not Found: Nuruljpg/index
ERROR - 2022-12-21 14:01:20 --> 404 Page Not Found: Nuruljpg/index
ERROR - 2022-12-21 14:04:31 --> 404 Page Not Found: Nuruljpg/index
ERROR - 2022-12-21 14:04:46 --> 404 Page Not Found: GetNilaiByNik/index
ERROR - 2022-12-21 14:04:56 --> 404 Page Not Found: Nuruljpg/index
ERROR - 2022-12-21 14:05:22 --> 404 Page Not Found: GetNilaiByNik/index
ERROR - 2022-12-21 14:06:01 --> 404 Page Not Found: Nuruljpg/index
ERROR - 2022-12-21 14:07:59 --> 404 Page Not Found: Undefined/index
ERROR - 2022-12-21 20:08:00 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 119
ERROR - 2022-12-21 20:08:00 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 121
ERROR - 2022-12-21 20:08:00 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 123
ERROR - 2022-12-21 20:08:00 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 124
ERROR - 2022-12-21 20:08:00 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 119
ERROR - 2022-12-21 20:08:00 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 121
ERROR - 2022-12-21 20:08:00 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 123
ERROR - 2022-12-21 20:08:00 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 124
ERROR - 2022-12-21 20:08:00 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 119
ERROR - 2022-12-21 20:08:00 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 121
ERROR - 2022-12-21 20:08:00 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 123
ERROR - 2022-12-21 20:08:00 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 124
ERROR - 2022-12-21 14:08:14 --> 404 Page Not Found: Undefined/index
ERROR - 2022-12-21 20:08:15 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 119
ERROR - 2022-12-21 20:08:15 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 121
ERROR - 2022-12-21 20:08:15 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 123
ERROR - 2022-12-21 20:08:15 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 124
ERROR - 2022-12-21 20:08:15 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 119
ERROR - 2022-12-21 20:08:15 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 121
ERROR - 2022-12-21 20:08:15 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 123
ERROR - 2022-12-21 20:08:15 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 124
ERROR - 2022-12-21 20:08:15 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 119
ERROR - 2022-12-21 20:08:15 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 121
ERROR - 2022-12-21 20:08:15 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 123
ERROR - 2022-12-21 20:08:15 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 124
ERROR - 2022-12-21 14:08:38 --> 404 Page Not Found: Undefined/index
ERROR - 2022-12-21 20:08:39 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 119
ERROR - 2022-12-21 20:08:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 121
ERROR - 2022-12-21 20:08:39 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 123
ERROR - 2022-12-21 20:08:39 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 124
ERROR - 2022-12-21 20:08:39 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 119
ERROR - 2022-12-21 20:08:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 121
ERROR - 2022-12-21 20:08:39 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 123
ERROR - 2022-12-21 20:08:39 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 124
ERROR - 2022-12-21 20:08:39 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 119
ERROR - 2022-12-21 20:08:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 121
ERROR - 2022-12-21 20:08:39 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 123
ERROR - 2022-12-21 20:08:39 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 124
ERROR - 2022-12-21 14:08:52 --> 404 Page Not Found: Undefined/index
ERROR - 2022-12-21 20:16:41 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 119
ERROR - 2022-12-21 20:16:41 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 121
ERROR - 2022-12-21 20:16:41 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 123
ERROR - 2022-12-21 20:16:41 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 124
ERROR - 2022-12-21 20:16:41 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 119
ERROR - 2022-12-21 20:16:41 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 121
ERROR - 2022-12-21 20:16:41 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 123
ERROR - 2022-12-21 20:16:41 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 124
ERROR - 2022-12-21 20:16:41 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 119
ERROR - 2022-12-21 20:16:41 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 121
ERROR - 2022-12-21 20:16:41 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 123
ERROR - 2022-12-21 20:16:41 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 124
ERROR - 2022-12-21 20:17:25 --> Severity: Warning --> Illegal string offset 'total_record' C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 108
ERROR - 2022-12-21 20:17:25 --> Severity: Warning --> Illegal string offset 'total_record' C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 109
ERROR - 2022-12-21 20:17:25 --> Severity: Warning --> Illegal string offset 'data' C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 115
ERROR - 2022-12-21 20:17:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 115
ERROR - 2022-12-21 20:18:03 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 119
ERROR - 2022-12-21 20:18:03 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 121
ERROR - 2022-12-21 20:18:03 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 123
ERROR - 2022-12-21 20:18:03 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 124
ERROR - 2022-12-21 20:18:03 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 119
ERROR - 2022-12-21 20:18:03 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 121
ERROR - 2022-12-21 20:18:03 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 123
ERROR - 2022-12-21 20:18:03 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 124
ERROR - 2022-12-21 20:18:03 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 119
ERROR - 2022-12-21 20:18:03 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 121
ERROR - 2022-12-21 20:18:03 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 123
ERROR - 2022-12-21 20:18:03 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 124
ERROR - 2022-12-21 20:19:07 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 123
ERROR - 2022-12-21 20:19:07 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 124
ERROR - 2022-12-21 20:19:07 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 123
ERROR - 2022-12-21 20:19:07 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 124
ERROR - 2022-12-21 20:19:07 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 123
ERROR - 2022-12-21 20:19:07 --> Severity: Notice --> Undefined index: id_pelajaran C:\xampp\htdocs\sekolah_fe\application\controllers\Table_json.php 124
ERROR - 2022-12-21 14:26:53 --> 404 Page Not Found: Pelajaran/get
