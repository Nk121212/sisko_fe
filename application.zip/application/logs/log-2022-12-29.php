<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-12-29 05:24:19 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-12-29 05:24:19 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-12-29 05:24:19 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-12-29 05:24:19 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-12-29 05:29:50 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-12-29 05:29:50 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-12-29 05:29:50 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-12-29 05:29:50 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-12-29 05:31:06 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-12-29 05:31:06 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-12-29 05:31:06 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-12-29 05:31:06 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-12-29 05:44:11 --> 404 Page Not Found: Table_json/get_tingkat_all
ERROR - 2022-12-29 06:46:36 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-12-29 06:46:36 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-12-29 06:46:36 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-29 06:46:36 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-12-29 06:46:36 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-12-29 06:46:40 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-12-29 06:46:40 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-12-29 06:46:40 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-12-29 06:46:40 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-29 06:46:40 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-12-29 06:49:05 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-12-29 06:49:05 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-29 06:50:46 --> 404 Page Not Found: Assets/vendor
ERROR - 2022-12-29 06:50:59 --> 404 Page Not Found: Master/menu_page
ERROR - 2022-12-29 13:15:11 --> Severity: Notice --> Undefined index: nama_role C:\xampp\htdocs\sekolah_fe\application\views\logged_in\master\akses.php 60
ERROR - 2022-12-29 13:15:11 --> Severity: Notice --> Undefined index: nama_role C:\xampp\htdocs\sekolah_fe\application\views\logged_in\master\akses.php 60
ERROR - 2022-12-29 13:15:11 --> Severity: Notice --> Undefined index: nama_role C:\xampp\htdocs\sekolah_fe\application\views\logged_in\master\akses.php 60
ERROR - 2022-12-29 13:15:11 --> Severity: Notice --> Undefined index: nama_role C:\xampp\htdocs\sekolah_fe\application\views\logged_in\master\akses.php 60
ERROR - 2022-12-29 13:15:11 --> Severity: Notice --> Undefined index: nama_role C:\xampp\htdocs\sekolah_fe\application\views\logged_in\master\akses.php 60
ERROR - 2022-12-29 13:15:11 --> Severity: Notice --> Undefined index: nama_role C:\xampp\htdocs\sekolah_fe\application\views\logged_in\master\akses.php 60
ERROR - 2022-12-29 13:15:11 --> Severity: Notice --> Undefined index: nama_role C:\xampp\htdocs\sekolah_fe\application\views\logged_in\master\akses.php 60
ERROR - 2022-12-29 13:15:11 --> Severity: Notice --> Undefined index: nama_role C:\xampp\htdocs\sekolah_fe\application\views\logged_in\master\akses.php 60
ERROR - 2022-12-29 13:15:11 --> Severity: Notice --> Undefined index: nama_role C:\xampp\htdocs\sekolah_fe\application\views\logged_in\master\akses.php 60
ERROR - 2022-12-29 13:15:11 --> Severity: Notice --> Undefined index: nama_role C:\xampp\htdocs\sekolah_fe\application\views\logged_in\master\akses.php 60
ERROR - 2022-12-29 13:15:11 --> Severity: Notice --> Undefined index: nama_role C:\xampp\htdocs\sekolah_fe\application\views\logged_in\master\akses.php 60
ERROR - 2022-12-29 13:15:11 --> Severity: Notice --> Undefined index: nama_role C:\xampp\htdocs\sekolah_fe\application\views\logged_in\master\akses.php 60
ERROR - 2022-12-29 13:15:11 --> Severity: Notice --> Undefined index: nama_role C:\xampp\htdocs\sekolah_fe\application\views\logged_in\master\akses.php 60
ERROR - 2022-12-29 13:15:11 --> Severity: Notice --> Undefined index: nama_role C:\xampp\htdocs\sekolah_fe\application\views\logged_in\master\akses.php 60
ERROR - 2022-12-29 13:15:11 --> Severity: Notice --> Undefined index: nama_role C:\xampp\htdocs\sekolah_fe\application\views\logged_in\master\akses.php 122
ERROR - 2022-12-29 13:15:11 --> Severity: Notice --> Undefined index: nama_role C:\xampp\htdocs\sekolah_fe\application\views\logged_in\master\akses.php 122
ERROR - 2022-12-29 13:15:11 --> Severity: Notice --> Undefined index: nama_role C:\xampp\htdocs\sekolah_fe\application\views\logged_in\master\akses.php 122
ERROR - 2022-12-29 13:15:11 --> Severity: Notice --> Undefined index: nama_role C:\xampp\htdocs\sekolah_fe\application\views\logged_in\master\akses.php 122
ERROR - 2022-12-29 13:15:11 --> Severity: Notice --> Undefined index: nama_role C:\xampp\htdocs\sekolah_fe\application\views\logged_in\master\akses.php 122
ERROR - 2022-12-29 13:15:11 --> Severity: Notice --> Undefined index: nama_role C:\xampp\htdocs\sekolah_fe\application\views\logged_in\master\akses.php 122
ERROR - 2022-12-29 13:15:11 --> Severity: Notice --> Undefined index: nama_role C:\xampp\htdocs\sekolah_fe\application\views\logged_in\master\akses.php 122
ERROR - 2022-12-29 13:15:11 --> Severity: Notice --> Undefined index: nama_role C:\xampp\htdocs\sekolah_fe\application\views\logged_in\master\akses.php 122
ERROR - 2022-12-29 13:15:11 --> Severity: Notice --> Undefined index: nama_role C:\xampp\htdocs\sekolah_fe\application\views\logged_in\master\akses.php 122
ERROR - 2022-12-29 13:15:11 --> Severity: Notice --> Undefined index: nama_role C:\xampp\htdocs\sekolah_fe\application\views\logged_in\master\akses.php 122
ERROR - 2022-12-29 13:15:11 --> Severity: Notice --> Undefined index: nama_role C:\xampp\htdocs\sekolah_fe\application\views\logged_in\master\akses.php 122
ERROR - 2022-12-29 13:15:11 --> Severity: Notice --> Undefined index: nama_role C:\xampp\htdocs\sekolah_fe\application\views\logged_in\master\akses.php 122
ERROR - 2022-12-29 13:15:11 --> Severity: Notice --> Undefined index: nama_role C:\xampp\htdocs\sekolah_fe\application\views\logged_in\master\akses.php 122
ERROR - 2022-12-29 13:15:11 --> Severity: Notice --> Undefined index: nama_role C:\xampp\htdocs\sekolah_fe\application\views\logged_in\master\akses.php 122
ERROR - 2022-12-29 22:19:41 --> Severity: Notice --> Undefined variable: list_tingkat C:\xampp\htdocs\sekolah_fe\application\views\logged_in\transaksi\nilai.php 10
ERROR - 2022-12-29 22:19:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\logged_in\transaksi\nilai.php 10
ERROR - 2022-12-29 22:19:41 --> Severity: Notice --> Undefined variable: list_kelas C:\xampp\htdocs\sekolah_fe\application\views\logged_in\transaksi\nilai.php 21
ERROR - 2022-12-29 22:19:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\logged_in\transaksi\nilai.php 21
ERROR - 2022-12-29 22:19:41 --> Severity: Notice --> Undefined variable: list_pelajaran C:\xampp\htdocs\sekolah_fe\application\views\logged_in\transaksi\nilai.php 31
ERROR - 2022-12-29 22:19:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\sekolah_fe\application\views\logged_in\transaksi\nilai.php 31
